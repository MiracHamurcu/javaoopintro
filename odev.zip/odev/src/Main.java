public class Main {
    public static void main(String[] args) {
        Course course1 = new Course(1, "(2022) Yazılım Geliştirici Yetiştirme Kampı - JAVA", "Java", "Engin Demiroğ", "Java Yazılım Geliştirici Yetiştirme Kampımızın takip, döküman ve duyurularını buradan yapacağız.");
        Course course2 = new Course(2, "Senior Yazılım Geliştirici Yetiştirme Kampı (.NET)", ".Net", "Engin Demiroğ", "Senior Yazılım Geliştirici Yetiştirme Kampımızın takip, döküman ve duyurularını buradan yapacağız." );


        Course[] courses = {course1, course2};
        for (Course course: courses){
            System.out.println(course.name);
        }
        CourseManager courseManager = new CourseManager();
            courseManager.startCourse(course1);
        courseManager.startCourse(course2);
    }
}