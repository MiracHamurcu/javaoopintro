public class Course {
    int id;
    String name;
    String lang;
    String teacherName;
    String detail;

    public Course(int id, String name, String lang, String teacherName, String detail){
        this.id= id;
        this.name= name;
        this.lang = lang;
        this.teacherName= teacherName;
        this.detail= detail;
    }
}
