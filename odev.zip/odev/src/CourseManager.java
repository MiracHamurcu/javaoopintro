public class CourseManager {
    public void startCourse(Course course){
        System.out.println("2 Ay boyunca kurs başlatıldı. Kurs:"+course.name);
    }
}
